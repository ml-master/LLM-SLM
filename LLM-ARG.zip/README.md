# ARG

探索大预言模型在假新闻检测中的作用：

Official repository for ["**Bad Actor, Good Advisor: Exploring the Role of Large Language Models in Fake News Detection**"](https://arxiv.org/abs/2309.12247), which has been accepted by AAAI 2024.

## Dataset

The original datasets for the paper are located in the data folder, named with the suffix _yuan, such as train_yuan.Note that you can download the datasets only after an ["Application to Use the Datasets from ARG for Fake News Detection"](https://forms.office.com/r/eZELqSycgn) has been submitted.

Replace the dataset with data from the Content-based Fake dataset and Style-based Fake dataset where the origin_label is 'fake', and save it as dataset.json.


## Code

### Requirements

- python==3.10.13

- CUDA: 11.3

- Python Packages:

  ```
  pip install -r requirements.txt
  ```

### Pretrained Models

You can download pretrained models ([bert-base-uncased](https://huggingface.co/google-bert/bert-base-uncased) and [chinese-bert-wwm-ext](https://huggingface.co/hfl/chinese-bert-wwm-ext)) and change paths (`bert_path`) in the corresponding scripts.

### Run

You can run this model through `run_en.sh` for english dataset. 

To run the code,place the data from train_data, test_data, and val_data into the data folder.

Place the bert-base-uncased into the source data.

