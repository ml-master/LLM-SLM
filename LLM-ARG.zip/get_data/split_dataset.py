import pandas as pd
import json
from sklearn.model_selection import train_test_split

with open('../dataset.json', 'r', encoding='utf-8') as file:
    data = json.load(file)

# 直接将列表转换成DataFrame
df = pd.DataFrame(data)
# 去掉前缀转为数值型
df['origin_id'] = pd.to_numeric(df['origin_id'].str.replace('gossipcop-', ''), errors='coerce')
# 将原始数据集分为 70% 训练集和 30% 临时集合
train, temp_data = train_test_split(df, test_size=0.3, random_state=42)

# 将临时集合分为 50% 评估集和 50% 测试集
val, test = train_test_split(temp_data, test_size=0.5, random_state=42)

train['split'] = 'train'
val['split'] = 'val'
test['split'] = 'test'

train.to_json('train.json', orient='records')
val.to_json('val.json', orient='records')
test.to_json('test.json', orient='records')

