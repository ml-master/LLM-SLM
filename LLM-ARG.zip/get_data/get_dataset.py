import pandas as pd
import json
# 打开并读取JSON文件
with open('../pre_data/updated2fake_gossipcop_v3-2_content_based_fake.json', 'r', encoding='utf-8') as file:
    data1 = json.load(file)

with open('../pre_data/updated2_gossipcop_v3-2_content_based_fake.json', 'r', encoding='utf-8') as file:
    data2 = json.load(file)

# 直接将列表转换成DataFrame
df1 = pd.DataFrame(data1)
df2 = pd.DataFrame(data2)


result = pd.concat([df1, df2], ignore_index=True)
# 把数据中含有error的过滤掉
filtered_result = result[result['td_pred'] != 'error'].copy()
filtered_result1 = filtered_result[filtered_result['cs_pred'] != 'error'].copy()
filtered_result1['td_pred'] = filtered_result1['td_pred'].astype(int)
filtered_result1['td_acc'] = filtered_result1['td_acc'].astype(int)
filtered_result1['cs_pred'] = filtered_result1['cs_pred'].astype(int)
filtered_result1['cs_acc'] = filtered_result1['cs_acc'].astype(int)

filtered_result1['origin_label'] = filtered_result1['origin_label'].map({'fake': 1, 'legitimate': 0})

filtered_result1.to_json('dataset.json', orient='records')