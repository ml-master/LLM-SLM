import openai
import pandas as pd
import json
from zhipuai import ZhipuAI

# 设置ZhipuAI的API密钥
api_key = '0f8af808e63007959efa4bba7a26904f.EwWtv7AJVr7DJGIf'

# 创建ZhipuAI客户端
client = ZhipuAI(api_key=api_key)

# 打开并读取JSON文件
with open('../pre_data/updatedfake_gossipcop_v3-2_content_based_fake.json', 'r', encoding='utf-8') as file:
    data = json.load(file)



# 直接将列表转换成DataFrame
df = pd.DataFrame(data)
# 转置 DataFrame
# df_transposed = df.transpose()
#
# # 初始化一个空的 DataFrame，列为期望的字段名称
# new_df = pd.DataFrame(columns=['origin_id', 'origin_label', 'origin_text', 'generated_text', 'generated_tone'])
#
# # 用于存放所有记录的列表
# records = []
#
# # 遍历每一行，将数据添加到 records 列表中
# for index, row in df_transposed.iterrows():
#     record = {
#         'origin_id': index,
#         'origin_label': row.get('origin_label', None),
#         'origin_text': row.get('origin_text', None),
#         'generated_text': row.get('generated_text', None),
#         'generated_tone': row.get('generated_tone', None)
#     }
#     records.append(record)
#
# # 将记录列表转换为 DataFrame
# new_df = pd.DataFrame(records)
# # 创建一个空的列表来存储每行的数据
# rows = []
#
# # 从当前的 DataFrame 中读取每个列（即每个记录）
# for column in df.columns:
#     # 创建一个字典来存储每个字段的数据
#     record = {
#         'origin_id': df[column]['origin_id'],
#         'origin_label': df[column]['origin_label'],
#         'origin_text': df[column]['origin_text'],
#         'generated_text': df[column]['generated_text'],
#         'generated_tone': df[column]['generated_tone']
#     }
#     # 将这个记录添加到列表中
#     rows.append(record)
#
# # 将列表转换为一个新的 DataFrame
# new_df = pd.DataFrame(rows)
# 确保 'origin_id' 列存在且为索引
# df.set_index('origin_id', inplace=True)
#
# # 将 DataFrame 转换为字典，其中键是 'origin_id'
# data_dict = df.to_dict('index')
#
# # 保存字典为 JSON 文件，使用 indent 参数美化输出格式
# with open('./pre_data/final_gossipcop_content.json', 'w', encoding='utf-8') as file:
#     json.dump(data_dict, file, indent=4)
# # 打印新的 DataFrame 的前几行以检查其结构
# filtered_df = new_df[new_df['origin_label'] == 'fake']
#
# # 保存筛选后的DataFrame到新的JSON文件
# filtered_df.to_json('./pre_data/fake_gossipcop_content.json', orient='records')
#
# 更新cs_acc
df['cs_acc'] = df.apply(lambda row: 1 if (row['origin_label'] == 'fake' and row['cs_pred'] == "1") else row['cs_acc'], axis=1)

# 更新td_acc
df['td_acc'] = df.apply(lambda row: 1 if (row['origin_label'] == 'fake' and row['td_pred'] == "1") else row['td_acc'], axis=1)
# 将DataFrame保存为JSON文件
df.to_json('./pre_data/updated2fake_gossipcop_v3-2_content_based_fake.json', orient='records')


# 查看DataFrame的头部信息
# print(df.head())

# 如果你想查看某个特定字段的内容，例如`origin_text`
# print(df['origin_text'].head())
#
# 对DataFrame中的每个'content'进行分析
def analyze_content(row):

    # 准备与模型交互的消息列表
    messages = [
        {"role": "system",
         "content": "You are an artificial intelligence assistant, tasked with analyzing given news and determining its authenticity."},
        {"role": "user",
         "content": f"Please provide an analysis of the following text from a textual description perspective to evaluate its authenticity. If the text is deemed to be false, use the word 'fake'; if it is true, use the word 'real'.\"{row['origin_text']}\"."}
    ]
    try:
        # 使用ZhipuAI的API调用glm-4模型
        response = client.chat.completions.create(
            model="GLM-4-Flash",
            messages=messages,
            temperature=0.7,  # 根据需要调整
            top_p=1,  # 根据需要调整
            stream=False  # 根据需要调整
        )
        # result_text = response.choices[0].message['content'].strip()  # 确保使用正确的属性
        # # 假设模型的输出中包含'fake'或'real'来直接指示文本的真实性
        # is_fake = '1' if 'fake' in result_text.lower() else '0'
        # 根据智谱AI的返回格式正确解析结果
        result_text = response.choices[0].message.content
        # 假设模型的输出中包含'fake'或'real'来直接指示文本的真实性
        is_fake = '1' if 'fake' in result_text.lower() else '0'
        # 分析内容作为rationale
        rationale = f"{result_text}Based on the analysis, the content is considered {'fake' if is_fake == '1' else 'real'}."
        # 打印语句，提示成功处理
        print(f"Successfully processed row with rationale")
    except Exception as e:
        print(f"Error processing row: {e}")
        is_fake = 'error'
        rationale = "Error in analysis."
    return pd.Series([rationale, is_fake])

def analyze_common_sense(row):
    # 准备与模型交互的消息列表
    messages = [
        {"role": "system",
         "content": "You are an artificial intelligence assistant, tasked with analyzing given news and determining its authenticity."},
        {"role": "user",
         "content": f"Please provide an analysis of the following text from a common sense perspective to evaluate its authenticity. If the text is deemed to be false, use the word 'fake'; if it is true, use the word 'real'. \"{row['origin_text']}\"."}
    ]
    try:
        # 使用ZhipuAI的API调用glm-4模型
        response = client.chat.completions.create(
            model="GLM-4-Flash",
            messages=messages,
            temperature=0.7,  # 根据需要调整
            top_p=1,  # 根据需要调整
            stream=False  # 根据需要调整
        )
        # # 正确地解析结果
        # result_text = response.choices[0].message['content'].strip()  # 确保使用正确的属性
        #
        # # 假设模型的输出中包含'fake'或'real'来直接指示文本的真实性
        # is_fake = '1' if 'fake' in result_text.lower() else '0'
        # 根据智谱AI的返回格式正确解析结果
        result_text = response.choices[0].message.content

        # 假设模型的输出中包含'fake'或'real'来直接指示文本的真实性
        is_fake = '1' if 'fake' in result_text.lower() else '0'
        # 分析内容作为rationale
        rationale = f"{result_text}Based on the analysis, the content is considered {'fake' if is_fake == '1' else 'real'}."
        # 打印语句，提示成功处理
        print(f"Successfully processed row with rationale: {rationale}")
    except Exception as e:
        print(f"Error processing row: {e}")
        is_fake = 'error'
        rationale = "Error in analysis."
    return pd.Series([rationale, is_fake])

# 应用函数到DataFrame
# 应用 analyze_content 函数
new_df[['td_rationale', 'td_pred']] = new_df.apply(analyze_content, axis=1)
new_df['td_acc'] = (new_df['td_pred'].astype(str) == new_df['origin_label'].astype(str)).astype(int)

# 应用 analyze_common_sense 函数
new_df[['cs_rationale', 'cs_pred']] = new_df.apply(analyze_common_sense, axis=1)
new_df['cs_acc'] = (new_df['cs_pred'].astype(str) == new_df['origin_label'].astype(str)).astype(int)

# 保存结果到新的JSON文件
new_df.to_json('./pre_data/updatedfake_gossipcop_v3-2_content_based_fake.json', orient='records')
# # 设置OpenAI的API密钥
# openai.api_key = 'sk-proj-JBO4UWdhuQykphZbIkqMT3BlbkFJbrAtDCCTyVzxhOZaP2lP'
#
# # 打开并读取JSON文件
# with open('./pre_data/gossipcop_v3-1_style_based_fake.json', 'r', encoding='utf-8') as file:
#     data = json.load(file)
#
# # 创建一个空的列表来存储每行的数据
# rows = []
#
# # 遍历字典，提取数据
# for key, value in data.items():
#     # 添加一个字段来存储原始的键（例如`gossipcop-2493749932`）
#     value['id'] = key
#     rows.append(value)
#
# # 转换成DataFrame
# df = pd.DataFrame(rows)
#
# # 查看DataFrame的头部信息
# print(df.head(1).id)
#
# # 如果你想查看某个特定字段的内容，例如`origin_text`
# print(df['origin_text'].head())
#
# # 对DataFrame中的每个'content'进行分析
# def analyze_content(row):
#     try:
#         # 使用OpenAI的API调用，这里假设是用来预测文本真伪的模型
#         response = openai.Completion.create(
#             model="gpt-3.5-turbo-instruct",  # 使用更新的模型名称
#             prompt=f"Provide a textual description analysis of the following text to assess its truthfulness and potential misleading elements: \"{row['origin_text']}\".",
#             max_tokens=1024
#         )
#         # 解析结果
#         result = response.choices[0].text.strip()
#         is_fake = '1' if 'fake' in result.lower() else '0'
#         # 分析内容作为rationale
#         rationale = f"Based on the analysis, the content is considered {'fake' if is_fake == '1' else 'real'}."
#     except Exception as e:
#         print(f"Error processing row: {e}")
#         is_fake = 'error'
#         rationale = "Error in analysis."
#     return pd.Series([rationale, is_fake])
#
# # 应用函数到DataFrame
# df[['td_rationale', 'td_pred']] = df.apply(analyze_content, axis=1)
#
# # 添加新列 'td_acc'，比较 'td_pred' 和 'label'
# df['td_acc'] = (df['td_pred'].astype(str) == df['origin_label'].astype(str)).astype(int)
#
# # 查看结果
# print(df.head())
#
# # 可选：保存结果到新的JSON文件
# df.to_json('./pre_data/updated_gossipcop_v3-1_style_based_fake.json', orient='records')
# # 使用OpenAI的GPT-3 API分析数据
# results = []
# for col in data.columns:
#     # 构建分析提示
#     prompt = f"Please analyze the '{col}' column of the dataset"
#
#     # 调用GPT-3 API
#     response = openai.Completion.create(
#         engine='davinci',
#         prompt=prompt,
#         max_tokens=1024,
#         n=1,
#         stop=None,
#         temperature=0.5,
#     )
#
#     # 将分析结果添加到列表中
#     result = response.choices[0].text.strip()
#     results.append(result)
#
# # 打印分析结果
# for i, col in enumerate(data.columns):
#     print(f"Analysis for column '{col}':")
#     print(results[i])
#     print('')